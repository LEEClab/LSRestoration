#'@title Finds the priority areas for restoration of any ecosystem services in BUNDLE 2
#' 
#'@name bundle2
#'
#'@description The aim of this function is to create a landscape pattern that prioritizes restoration in areas near the infrastructure needed for the service flow and near the already established SPUs in the landscape. We assumed that the areas restored within this bundle will need to be near infrastructure to guarantee ES delivery, and near already established SPU so that species of interest could more easily recolonize them. The user has the option to input a maximum distance from the infrastructure and from the already established SPUs.
#'
#'@param dir.grass The absolute filepath representing the folder where Grass GIS is installed.
#'@param output.name The name of the output raster map.
#'@param rest.map A restoration map, as raster file, which should contain the delimitation (or boundaries) of the area available for restoration in the study landscape and, if possible, a surface of restoration feasibility/suitability.
#'@param spu.map A binary raster map with the already established SPUs in the landscape. Cells in the map corresponding to SPU areas should have a value equal to 1 and everything else with value equal to zero.
#'@param infra.map A raster map with the location of the infrastructures needed for the service delivery. It should be a binary map with cells corresponding to the infrastructure sites with values equal 1 and the other cells with values equal zero.
#'@param dist.spu An integer number corresponding to the maximum distance (in meters) from the already established SPUs where the restoration areas should be located.
#'@param dist.infra An integer number corresponding to the maximum distance (in meters) from the infrastructure, where the restoration areas should be located.
#' 
#'@details The function will create a raster map with the Euclidian distances from the already established SPUs and other Euclidian distance map from the infrastructure sites. Both resultant distances maps will integrate a Generalized Linear Model (GLM) analysis that will predict the benefit in restoring in each one of the landscape cells. Both maximum distances will serve as a weight for the corresponding explanatory variable (distance from SPU and infrastructure maps) in the GLM. As both maximum distances are optional inputs, if the user chooses not to input one or both variables, the function will use the highest value in the corresponding distance map. The final step is to multiply the resultant map from the GLM analysis with the restoration map.
#'
#'@return A map with restoration priorities for the mantainance of the ecosystem service.
#'
#'@author Gabriela Teixeira Duarte, Felipe Martello, Milton Cezar Ribeiro
#'
#'@seealso \url{link github}, \url{link artigo}
#'
#'@examples 
#' bundle2(rest.map = "pasture.tif",spu.map = "savana.tif",infra.map = "processing_plants.tif",dist.infra=3000, dist.spu=1500,output.name="restbundle2.tif", dir.grass="C:\\Program Files\\GRASS GIS 7.4.0")
#'
#' dir.grass<-"C:\\Program Files\\GRASS GIS 7.4.0"
#' output.name<-"restbundle2.tif" 
#' spu.map<-raster("forest.tif")
#' infra.map<-raster("road.tif") 
#' dist.spu<-850
#' dist.infra<-1000
#' bundle2.results<- bundle2(dir.grass, rest.map, spu.map, infra.map, dist.spu, distinfra, output.name)
#'
#'@import raster
#'@import rgdal
#'@import rgrass7
#'@import akima
#'
#'@export

bundle2<-function(dir.grass, rest.map, spu.map, infra.map, dist.spu = max.distance.spu, dist.infra = max.distance.infra, output.name){ 
  
  #adress of grass directory
  initGRASS(gisBase = dir.grass, home = getwd(), gisDbase=getwd(),override=TRUE)
  
  #reformulating the input raster maps  
  rest.map.na<-rest.map
  infra.map.na<-infra.map
  spu.map.na<-spu.map
  
  rest.map.na[rest.map.na==0]<-NA
  infra.map.na[infra.map.na!=1]<-NA
  spu.map.na[spu.map.na!=1]<-NA
  
  #creating an Euclidian distance map from spu.map
  writeRAST(as(spu.map.na, "SpatialGridDataFrame"), "spu.map.na2", flags = c("overwrite"))
  execGRASS("g.region",raster = "spu.map.na2")
  execGRASS("r.grow.distance", flags="overwrite", parameters=list(input="spu.map.na2", distance="distance.spu.map.na2"))
  dist.spu.map<-raster(readRAST("distance.spu.map.na2"))
  max.distance.spu<-max(na.omit(dist.spu.map[]))
  dist.spu.map[dist.spu.map>dist.spu]<-dist.spu
  
  #creating an Euclidian distance map from infra.map
  writeRAST(as(infra.map.na, "SpatialGridDataFrame"), "infra.map.na2", flags = c("overwrite"))
  execGRASS("r.grow.distance", flags="overwrite", parameters=list(input="infra.map.na2", distance="distance.infra.map.na2"))
  dist.infra.map<-raster(readRAST("distance.infra.map.na2"))
  max.distance.infra<-max(na.omit(dist.infra.map[]))
  dist.infra.map[dist.infra.map>dist.infra]<-dist.infra
  
  #data to create model of restauration benefits as response variable 
  mt<-data.frame(matrix(c(0,1,0.2,0.446428571,0.708333333,0.991071429,0.892857143,0,0.807261905,0.154761905,0.363095238,0.571428571,0.794642857,0.720238095,0,0.604166667,0.116071429,0.270833333,0.428571429,0.610119048,0.541666667,0,0.403571429,0.077380952,0.181547619,0.357142857,0.398809524,0.363095238,0,1,0,0.991071429,0.892857143,0.708333333,0.2,0.446428571,0.807261905,0,0.794642857,0.720238095,0.571428571,0.154761905,0.363095238,0.604166667,0,0.610119048,0.541666667,0.428571429,0.116071429,0.270833333,0.403571429,0,0.398809524,0.363095238,0.285714286,0.077380952,0.181547619,0,0,0,0,0,0,0,0,0.25,0.25,0.25,0.25,0.25,0.25,0.25,0.5,0.5,0.5,0.5,0.5,0.5,0.5,0.75,0.75,0.75,0.75,0.75,0.75,0.75,1),ncol=3,byrow=FALSE))
  colnames(mt)<-c("x","y","z")
  
  #inserting the distance maps into the model created
  mt$x<-mt$x*dist.spu
  mt$y<-mt$y*dist.infra
  mod<-glm(z ~ x * y, data=mt,family=gaussian)
  
  #ploting relation between spu, infra and restoration benefits
  mt$estimate<-predict.glm(mod, newdata=mt[,1:2],type="response")
  mt$estimate<-mt$estimate/max(mt$estimate)
  
  int<-interp(mt$x,mt$y,mt$estimate)
  image(int,col =gray.colors(20,start = 0.9, end = 0.3),xlab="Distance from SPU (m)",ylab="Distance from infrastructure (m)",cex.axis=1.0,cex.lab=1.0)
  contour(int, add=T,labcex = 1.5,col="gray30",lwd=2,method= "edge",drawlabels=TRUE)
  
  #predicting restoration benefits using the model 
  foo<-data.frame(cbind(dist.spu.map[],dist.infra.map[]))
  colnames(foo)<-c("x","y")
  foo$estimate<-predict.glm(mod, newdata=foo,type="response")
  foo.benf<-dist.infra.map
  foo.benf[]<-foo$estimate
  foo.benf[foo.benf<0]<-0
  
  #clipping by potential restoration areas
  rest.benf<-foo.benf*rest.map.na
    
  #forcing range from 0 to 1 
  rest.priority2<-rest.benf
  rest.priority2[]<-rest.benf[]/max(na.omit(rest.benf[]))
  crs(rest.priority2)<-crs(rest.map)
  plot(rest.priority2)

  #saving output
  writeRaster(rest.priority2,output.name,overwrite=TRUE)
  
  #removing temporary folder
  temp_dir<-paste(getwd(),gmeta()$LOCATION_NAME[1],sep="/")
  unlink(temp_dir,recursive=T,force=T)

  return(rest.priority2)
}