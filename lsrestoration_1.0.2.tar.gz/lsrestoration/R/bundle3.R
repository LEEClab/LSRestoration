#' @title Finds the priority areas for restoration of any ecosystem services in BUNDLE 3.
#' @name bundle3
#'
#' @description The aim of the function is to give restoration priority to areas around the specific sites that need the ecosystem service. As this is a local service with in-situ delivery, we assume that the main landscape pattern contributing to the maintenance and improvement of the production of the service bundle will be que quantity of natural areas surrounding specific sites that need the service.
#'
#' @param dir.grass the absolute filepath representing the folder where Grass GIS is installed.
#' @param output.name the name of the output raster map.
#' @param rest.map a restoration map, as raster file, which should contain the delimitation (or boundaries) of the area available for restoration in the study landscape and, if possible, a surface of restoration feasibility/suitability.
#' @param site.map a raster map with the location of the sites that need the service. It should be a binary map with cells corresponding to the specific sites with values equal 1 and the other cells with values equal zero.
#' @param dist.site an integer value related to the maximum distance (in meters) from the site. This distance corresponds to the radius of the area of influence of the ecosystem service. 
#' @param alpha an integer value, between 1 and 5, that corresponds to the alpha parameter for the sigmoid curve. This parameter will change the inclination and shape of the curve. The higher the alpha, the sigmoid curve will be more and more like a linear function.
#' 
#' @details First, the function will create a raster map with the Euclidian distances from the sites. Then, it will use these values of distance and the alpha value, to construct a sigmoid function that gives new values to the cells. The final step is to multiply the resultant map from the sigmoid function with the restoration map ("rest.map").
#'
#' @return A map with restoration priorities for the mantainance of the ecosystem service.
#'
#' @author Gabriela Teixeira Duarte, Felipe Martello, Milton Cezar Ribeiro
#'
#' @seealso \url{link github}, \url{link artigo}
#'
#' @examples
#' bundle3(rest.map="pastures.tif",site.map="banana.tif",dist.site=3000,ouput.name="restbundle3.tif", dir.grass="C:\\Program Files\\GRASS GIS 7.4.0")
#'
#' dir.grass<-"C:\\Program Files\\GRASS GIS 7.4.0"
#' output.name<-"restbundle3.tif"
#' rest.map<-raster("restoration_areas.tif")
#' site.map<-raster("bioremediation.tif")
#' dist.site<-500
#' alpha<-2
#' bundle3.results<- bundle3(dir.grass, rest.map, site.map, dist.site, alpha, output.name)
#' 
#'@import raster
#'@import rgdal
#'@import rgrass7
#'
#' @export

bundle3<-function(dir.grass, rest.map, site.map, dist.site=max(na.omit(dist.map[])), alpha, output.name){
  
  #adress of grass directory
  initGRASS(gisBase = dir.grass, home = getwd(), gisDbase=getwd(),override=TRUE)
  
  #reformulating the input raster maps  
  rest.map.na<-rest.map
  site.map.na<-site.map
  
  rest.map.na[rest.map.na==0]<-NA
  site.map.na[site.map.na!=1]<-NA
  
  #creating distance map from site.map
  writeRAST(as(site.map.na, "SpatialGridDataFrame"), "mapNA", flags = c("overwrite"))
  execGRASS("g.region",raster = "mapNA")
  execGRASS("r.grow.distance", flags="overwrite", parameters=list(input="mapNA", distance="mapdistance"))
  dist.map<-raster(readRAST("mapdistance"))
  
  #sigmoid curve from distance map
  x<-dist.map[]
  x[x>dist.site]<-dist.site
  x<-x/max(x)*100 # converting to 0-100 raster
  
  a<-(alpha/10)*43.768+4.588  #adjusting alpha for the known raster range
  foo<--SSlogis(x, 1, 50, a)+1 #sigmoid function
  foo<-foo-min(foo)
  foo<-foo/max(foo)
  
  #ploting 
  foo2<-data.frame(cbind(na.omit(dist.map[]),na.omit(foo)))
  foo2<-foo2[sample(1:nrow(foo2),1000,replace=F),]
  par(mfrow=c(1,2))
  plot(foo2,xlim=c(0,max(dist.map[])),main=paste("Rest.priority x Distance (max) - alpha =",alpha), xlab="Distance (m)", ylab="Restoration priority")
  plot(foo2,xlim=c(0,dist.site),main=paste("Rest.priority x Distance (selected) - alpha =",alpha), xlab="Distance (m)", ylab="Restoration priority")
  
  #clipping by potential restoration areas
  sig.map<-rest.map.na
  sig.map[]<-foo
  rest.benf<-rest.map.na*sig.map
  
  #forcing range from 0 to 1 
  rest.priority3<-rest.benf/max(na.omit(rest.benf[]))
  crs(rest.priority3)<-crs(rest.map)
  plot(rest.priority3)
  
  #saving output
  writeRaster(rest.priority3,output.name,overwrite=TRUE)
  
  #removing temporary folder
  temp_dir<-paste(getwd(),gmeta()$LOCATION_NAME[1],sep="/")
  unlink(temp_dir,recursive=T,force=T)
  
  return(rest.priority3)
}
