#' @title Finds the priority areas for restoration of any ecosystem services in BUNDLE 7.
#' @name bundle7
#'
#' @description The aim of the function is to give restoration priority to areas near and within SBA, spaced apart, and sparse from the already established SPUs. We assume that the benefit of restoration is smaller near the already established SPUs, as these areas are already under the effects of the ESs that the SPUs provide. What the function of this bundle does is to create a solution with new restoration patches that are interleaved within and near the SBA areas. Each one of these patches will benefit the area surrounding it.
#'
#' @param dir.grass the absolute filepath representing the folder where Grass GIS is installed.
#' @param output.name the name of the output raster map.
#' @param rest.map a restoration map, as raster file, which should contain the delimitation (or boundaries) of the area available for restoration in the study landscape and, if possible, a surface of restoration feasibility/suitability.
#' @param spu.map a binary raster map with the already established SPUs in the landscape. Cells in the map corresponding to SPU areas should have a value equal to 1 and everything else with value equal to zero.
#' @param sba.map a raster map with SBA location in the landscape. Cells in the map corresponding to SBA areas should have a value different than zero and everything else with value equal to zero. The values of SBA cells should be relative and represent the demand for an ecosystem service.
#' @param patch.max the maximum size of a patch that will be restored, in square meters. This size is context dependent and should be defined as the sufficient area to provide the benefit for that distance of influence.
#' @param patch.min the minimum size of a patch that will be restored, in square meters. This size is context dependent and should be defined as the minimum area to be restored. That is, the minimum area that can provide the service.
#' @param dist.inf the distance, in meters, from the already established SPU and new patches that the service can percolate in the landscape
#' 
#'
#'
#' @return A map with restoration priorities for the mantainance of the ecosystem service.
#'
#' @author Gabriela Teixeira Duarte, Felipe Martello, Milton Cezar Ribeiro
#'
#' @seealso \url{link github}, \url{link artigo}
#'
#' @examples
#' bundle7(rest.map = "pasture.tif",spu.map = "forest.tif", sba.map = "pasture.tif", patch.max=10000, patch.min=80000, dist.infl=500,ouput.name="restbundle7.tif", dir.grass="C:\\Program Files\\GRASS GIS 7.4.0")
#'
#' dir.grass<-"C:\\Program Files\\GRASS GIS 7.4.0"
#' output.name<-"restbundle7.tif"
#' rest.map<-raster("restoration_areas.tif")
#' spu.map<-raster("forest.tif")
#' sba.map<-raster("pasture.tif")
#' patch.max<- 2000
#' patch.min<- 1500
#' dist.inf<- 350 
#'bundle7.results<- bundle7(dir.grass, rest.map, spu.map, sba.map, patch.max, patch.min, dist.inf, output.name)
#'
#'@import raster
#'@import rgdal
#'@import rgrass7
#'@import maptools
#'@import rgeos
#' @export 


bundle7<-function(dir.grass,rest.map,spu.map,sba.map,patch.max,patch.min,dist.inf,output.name){
  
  #adress of grass directory
  initGRASS(gisBase = dir.grass, home=getwd(), gisDbase=getwd(),override=TRUE)
  
  #reformulating the input raster maps  
  spu.map.na<-spu.map
  spu.map.na[spu.map.na!=1]<-NA
  
  sba.map.1na<-sba.map
  sba.map.1na[sba.map.1na!=0]<-1
  sba.map.1na[sba.map.1na==0]<-NA
  sba.mapV<-sba.map
  sba.mapV[sba.mapV==0]<-NA
  
  rest.mapV<-rest.map
  rest.mapV[rest.mapV==0]<-NA
  
  a<-patch.max #maximum area
  h<-dist.inf #distance of influence
  min_rest<-patch.min # minimum area to be restored
  
  ##settting Grass environment
  writeRAST(as(spu.map.na, "SpatialGridDataFrame"), "mapSPUNA", flags = c("overwrite"))
  execGRASS("g.region",raster = "mapSPUNA")
  
  #constructuring buffer region from SPUs
  wdw_size<-h*2
  execGRASS("r.buffer", flags="overwrite", parameters=list(input="mapSPUNA", output="buf.spu.map", distances=wdw_size, units="meters") )
  buff.spu.map<-raster(readRAST("buf.spu.map"))
  buff.spu.map[is.na(buff.spu.map)]<-1000
  buff.spu.map[buff.spu.map<1000]<-NA
  buff.spu.map[buff.spu.map==1000]<-1
  
  #cutting the sba.map
  cut.sba1na<-sba.map.1na*buff.spu.map
  cut.sbaV<-sba.mapV*buff.spu.map
  
  #hexagons_paramenters
  r<-sqrt(2*a/(3*sqrt(3)))
  b<-(r*sqrt(3))/2
  R<-r+h
  Ap<-(R*sqrt(3))/2
  y<-R-r
  d<-Ap-b
  z<-sqrt(y^2-d^2)
  
  #creating hexagon grid (including distance of influence)        
  r.mask<-cut.sba1na
  r.mask[is.na(r.mask)]<-1
  r.mask<-as(r.mask, "SpatialPixelsDataFrame")
  hex.pts<-spsample(r.mask,type="hexagonal", cellsize = 2*Ap, offset = c(0,0))
  hex.grid<- HexPoints2SpatialPolygons(hex.pts)
  p.df<-data.frame( ID=1:length(hex.grid)) 
  row.names(p.df) <- paste("ID",1:length(hex.grid),sep="")
  hex.grid<-SpatialPolygonsDataFrame(hex.grid,match.ID=T ,data=p.df)
  hex.grid@data$value<-1
  
  for( i in 1:length(hex.grid@polygons)){
    hex.grid@polygons[[i]]@Polygons[[1]]@coords[1,1]<-hex.grid@polygons[[i]]@Polygons[[1]]@coords[1,1]+d
    hex.grid@polygons[[i]]@Polygons[[1]]@coords[2,1]<-hex.grid@polygons[[i]]@Polygons[[1]]@coords[2,1]
    hex.grid@polygons[[i]]@Polygons[[1]]@coords[3,1]<-hex.grid@polygons[[i]]@Polygons[[1]]@coords[3,1]-d
    hex.grid@polygons[[i]]@Polygons[[1]]@coords[4,1]<-hex.grid@polygons[[i]]@Polygons[[1]]@coords[4,1]-d
    hex.grid@polygons[[i]]@Polygons[[1]]@coords[5,1]<-hex.grid@polygons[[i]]@Polygons[[1]]@coords[5,1]
    hex.grid@polygons[[i]]@Polygons[[1]]@coords[6,1]<-hex.grid@polygons[[i]]@Polygons[[1]]@coords[6,1]+d
    hex.grid@polygons[[i]]@Polygons[[1]]@coords[7,1]<-hex.grid@polygons[[i]]@Polygons[[1]]@coords[7,1]+d
    
    hex.grid@polygons[[i]]@Polygons[[1]]@coords[1,2]<-hex.grid@polygons[[i]]@Polygons[[1]]@coords[1,2]-z
    hex.grid@polygons[[i]]@Polygons[[1]]@coords[2,2]<-hex.grid@polygons[[i]]@Polygons[[1]]@coords[2,2]-y
    hex.grid@polygons[[i]]@Polygons[[1]]@coords[3,2]<-hex.grid@polygons[[i]]@Polygons[[1]]@coords[3,2]-z
    hex.grid@polygons[[i]]@Polygons[[1]]@coords[4,2]<-hex.grid@polygons[[i]]@Polygons[[1]]@coords[4,2]+z
    hex.grid@polygons[[i]]@Polygons[[1]]@coords[5,2]<-hex.grid@polygons[[i]]@Polygons[[1]]@coords[5,2]+y
    hex.grid@polygons[[i]]@Polygons[[1]]@coords[6,2]<-hex.grid@polygons[[i]]@Polygons[[1]]@coords[6,2]+z
    hex.grid@polygons[[i]]@Polygons[[1]]@coords[7,2]<-hex.grid@polygons[[i]]@Polygons[[1]]@coords[7,2]-z
  }
  
  #finding the hexagons within the restoration area
  writeVECT(hex.grid, "hex_sm",  v.in.ogr_flags = "o", driver = "ESRI Shapefile")
  execGRASS("v.to.rast", parameters = list(input="hex_sm",attribute_column="value",output="hexagons",use="attr"))
  writeRAST(as(rest.mapV, "SpatialGridDataFrame"), "mapRESTV", flags = c("overwrite"))
  execGRASS("r.mapcalc",flags=c("overwrite"), parameters=list(expression="hex_rest=hexagons*mapRESTV"))
  execGRASS("r.mapcalc",flags=c("overwrite"), parameters=list(expression="hex_rest2=hex_rest/hex_rest"))
  rest.hex<-raster(readRAST("hex_rest2"))
  
  #number of restoration pixels in the hexagons
  execGRASS("v.rast.stats", parameters=list(map="hex_sm", raster="hex_rest", column_prefix="core",method=c("number", "sum")))
  
  #buffer of restoration hexagons
  execGRASS("r.buffer",parameters = list(input="hex_rest", output="buf_hex_rest", distances=h))
  execGRASS("r.null",parameters = list(map="buf_hex_rest",setnull="1"))
  execGRASS("r.mapcalc", parameters = list(expression="buf_hex_rest1=buf_hex_rest/2"))

  #buffer of hexagons
  execGRASS("v.buffer",flags=c("overwrite","t"),parameters=list(input="hex_sm", distance=h,output="diff_hex"))
  
  #calculating SBA area that is benefited
  writeRAST(as(cut.sbaV, "SpatialGridDataFrame"), "cut.sba.map", flags = c("overwrite"))
  execGRASS("r.mapcalc",flags=c("overwrite"), parameters=list(expression="hex_sba=cut.sba.map*buf_hex_rest1"))
  execGRASS("v.rast.stats", parameters=list(map="diff_hex", raster="hex_sba", column_prefix="benef_rg",method=c("number","sum")))
  
  #exporting the maps to R environment
  hex.grid<-readVECT("hex_sm")
  hex.diff<-readVECT("diff_hex")
  dif.data<-hex.diff@data
  dif.data[is.na(dif.data)]<-0

  #creating the index
  dif.data$index<-dif.data$core_sum*dif.data$benef_rg_sum
  dif.data$index<-dif.data$index/max(dif.data$index)
  
  #patch area to be restored with corresponding benefited area
  reso<-res(rest.map)[1]
  dif.data$core_number<-dif.data$core_number*(reso^2)
  dif.data$benef_rg_number<-dif.data$benef_rg_number*(reso^2)
  dif.data<-dif.data[,c(2,4,6,8)]
  
  #constructing the output maps
  hex.grid@data<-dif.data
  hex.grid<-hex.grid[hex.grid@data$core_number>=min_rest,]

  r_index<-rasterize(hex.grid,rest.map,field="index")
  r_index[r_index==0]<-NA
  rest.priority7<-rest.hex*r_index
  crs(hex.grid)<-crs(rest.map)
  crs(rest.priority7)<-crs(rest.map)
  plot(rest.priority7)
  
  #saving output
  writeRaster(rest.priority7,output.name,overwrite=TRUE)
  
  #removing temporary folder
  temp_dir<-paste(getwd(),gmeta()$LOCATION_NAME[1],sep="/")
  unlink(temp_dir,recursive=T,force=T)
  
  return(list(rest.priority7,hex.grid))
  
}