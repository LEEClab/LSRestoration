#' @title Finds the priority areas for restoration of any ecosystem services in BUNDLE 6.
#' @name bundle6
#'
#' @description The aim of this function is to give restoration priority to areas around already established SPUs and consider the shape of the fragments to reduce edge effects, the matrix extension and the contrast between the SPU and the adjacent matrix. We assume that fragments with less edge effects, lower adjacent matrix extension and contrast will retain more carbon in the above and belowground biomass, contributing to mitigate the greenhouse effects.
#'
#' @param dir.grass the absolute filepath representing the folder where Grass GIS is installed.
#' @param output.name the name of the output raster map.
#' @param rest.map a restoration map, as raster file, which should contain the delimitation (or boundaries) of the area available for restoration in the study landscape and, if possible, a surface of restoration feasibility/suitability.
#' @param spu.map a binary raster map with the already established SPUs in the landscape. Cells in the map corresponding to SPU areas should have a value equal to 1 and everything else with value equal to zero. 
#' @param dist.edge an integer number corresponding to the distance (in meters) that the expected edge effects could percolate inside the SPUs and decrease carbon stock and sequestration.
#' 
#' @details The function will create a raster map with the Euclidian distances from the SPUs in the "spu.map". After it, the function also takes spu.map for a move-window analysis, where the central pixel will have the sum value of its neighbors. The "dist.edge" value corresponds to half of one of the move-window sides. In the last step, the function takes the new map created after the move-window analysis, the Euclidian distance map and multiply them both with the restoration map.
#'
#' @return A map with restoration priorities for the mantainance of the ecosystem service.
#'
#' @author Gabriela Teixeira Duarte, Felipe Martello, Milton Cezar Ribeiro
#'
#' @seealso \url{link github}, \url{link artigo}
#'
#' @examples
#' bundle6(rest.map = "pasture.tif",spu.map = "forest.tif",dist.edge=200,ouput.name="restbundle6.tif", dir.grass="C:\\Program Files\\GRASS GIS 7.4.0")
#'
#'
#' dir.grass<-"C:\\Program Files\\GRASS GIS 7.4.0"
#' output.name<-"restbundle6.tif"
#' rest.map<-raster("restoration_areas.tif")
#' spu.map<-raster("forest.tif")
#' dist.edge<-150
#' bundle6.results<- bundle6(dir.grass, rest.map, spu.map, dist.edge, output.name)
#'
#'@import raster
#'@import rgdal
#'@import rgrass7
#' @export

bundle6<-function(dir.grass,rest.map,spu.map,dist.edge,output.name){
  
  #adress of grass directory
  initGRASS(gisBase = dir.grass, home = getwd(), gisDbase=getwd(),override=TRUE)

  #reformulating the input raster maps  
  rest.map.na<-rest.map
  spu.map.na<-spu.map

  rest.map.na[rest.map.na==0]<-NA
  spu.map.na[spu.map.na!=1]<-NA

  #creating an Euclidian distance map from spu.map
  writeRAST(as(spu.map.na, "SpatialGridDataFrame"), "mapNA", flags = c("overwrite"))
  execGRASS("g.region",raster = "mapNA")
  execGRASS("r.grow.distance", flags="overwrite", parameters=list(input="mapNA", distance="distance.spu.map"))
  dist.map<-raster(readRAST("distance.spu.map"))
  dist.map<-max(dist.map[])-dist.map
  
  #creating moving-window
  mov.sz<-(floor((dist.edge/res(spu.map)[1]))*2)+1
  
  #executing moving-window analysis
  writeRAST(as(spu.map.na, "SpatialGridDataFrame"), "mapSPU", flags = c("overwrite"))
  execGRASS("r.neighbors", flags="overwrite", parameters=list(input="mapSPU", output="mapMOV", method="count", size=as.integer(mov.sz)) )
  mov.map<-raster(readRAST("mapMOV"))
  mov.map<-1+(mov.map/max(na.omit(mov.map[])))
  
  #multipling the maps
  benef.edge<-dist.map*mov.map
  
  #clipping by potential restoration areas
  rest.benf<-benef.edge*rest.map.na
  
  #forcing range from 0 to 1 
  rest.priority6<-rest.benf/max(na.omit(rest.benf[]))
  crs(rest.priority6)<-crs(rest.map)
  plot(rest.priority6)
  
  #saving output
  writeRaster(rest.priority6,output.name,overwrite=TRUE)
  
  #removing temporary folder
  temp_dir<-paste(getwd(),gmeta()$LOCATION_NAME[1],sep="/")
  unlink(temp_dir,recursive=T,force=T)
  
  return(rest.priority6)
}  