#' @title Finds the priority areas for restoration of any ecosystem services in BUNDLE 4.
#' @name bundle4
#'
#' @description  The aim of the function is to give restoration priority to areas buffering water bodies. We assume that areas surrounding water springs, rivers and lakes, will serve as the main source of water delivered services.
#'
#' @param dir.grass the absolute filepath representing the folder where Grass GIS is installed.
#' @param output.name the name of the output raster map.
#' @param rest.map a restoration map, as raster file, which should contain the delimitation (or boundaries) of the area available for restoration in the study landscape and, if possible, a surface of restoration feasibility/suitability.
#' @param water.map a raster map with the location of the water bodies that need or deliver the service. This is a binary map with cells corresponding to the water bodies with values equal 1 and the other cells values equal zero.
#' @param dist.water an integer value related to the maximum distance (in meters) from the water body. This distance corresponds to the maximum width of the buffer area that can influence the process occurring in water bodies. 
#' @param alpha an integer value, between 1 and 5, that corresponds to the alpha parameter for the sigmoid curve. This parameter will change the inclination and shape of the curve. The higher the alpha, the sigmoid curve will be more and more like a linear function.
#' 
#' @details First, the function will create a raster map with the Euclidian distances from the water bodies. Then, it will use these values of distance and the alpha value, to construct a sigmoid function that gives new values to the cells. The final step is to multiply the resultant map from the sigmoid function with the restoration map ("rest.map").
#'
#' @return A map with restoration priorities for the mantainance of the ecosystem service.
#'
#' @author Gabriela Teixeira Duarte, Felipe Martello, Milton Cezar Ribeiro
#'
#' @seealso \url{link github}, \url{link artigo}
#'
#' @examples
#' bundle4(rest.map="pastures.tif",water.map="watersprings.tif",dist.water=200,ouput.name="restbundle4.tif", dir.grass="C:\\Program Files\\GRASS GIS 7.4.0")
#'
#' dir.grass<-"C:\\Program Files\\GRASS GIS 7.4.0"
#' output.name<-"restbundle4.tif"
#' rest.map<-raster("restoration_areas.tif")
#' site.map<-raster("wetland_rivers.tif")
#' dist.site<-350
#' alpha<-1
#' #Running the bundle 4 function
#' bundle4.results<- bundle4(dir.grass, rest.map, water.map, dist.water, alpha, output.name)
#' 
#'@import raster
#'@import rgdal
#'@import rgrass7
#'
#' @export

bundle4<-function(dir.grass,rest.map, water.map, dist.water=max(na.omit(dist.map[])), alpha, output.name){
  
  #adress of grass directory
  initGRASS(gisBase = dir.grass, home = getwd(), gisDbase=getwd(),override=TRUE)
  
  #reformulating the input raster maps  
  rest.map.na<-rest.map
  water.map.na<-water.map
  
  rest.map.na[rest.map.na==0]<-NA
  water.map.na[water.map.na!=1]<-NA
  
  #creating distance map from water.map
  writeRAST(as(water.map.na, "SpatialGridDataFrame"), "mapNA", flags = c("overwrite"))
  execGRASS("g.region",raster = "mapNA")
  execGRASS("r.grow.distance", flags="overwrite", parameters=list(input="mapNA", distance="mapdistance"))
  dist.map<-raster(readRAST("mapdistance"))
  
  #sigmoid curve from distance map
  x<-dist.map[]
  x[x>dist.water]<-dist.water
  x<-x/max(x)*100 # converting to 0-100 raster
  
  a<-(alpha/10)*43.768+4.588  #adjusting alpha for the known raster range
  foo<--SSlogis(x, 1, 50, a)+1 #sigmoid function
  foo<-foo-min(foo)
  foo<-foo/max(foo)
  
  #ploting 
  foo2<-data.frame(cbind(na.omit(dist.map[]),na.omit(foo)))
  foo2<-foo2[sample(1:nrow(foo2),1000,replace=F),]
  par(mfrow=c(1,2))
  plot(foo2,xlim=c(0,max(dist.map[])),main=paste("Rest.priority x Distance (max) - alpha =",alpha), xlab="Distance (m)", ylab="Restoration priority")
  plot(foo2,xlim=c(0,dist.water),main=paste("Rest.priority x Distance (selected) - alpha =",alpha), xlab="Distance (m)", ylab="Restoration priority")
  
  #clipping by potential restoration areas
  sig.map<-rest.map.na
  sig.map[]<-foo
  rest.benf<-rest.map.na*sig.map
  
  #forcing range from 0 to 1 
  rest.priority4<-rest.benf/max(na.omit(rest.benf[]))
  crs(rest.priority4)<-crs(rest.map)
  plot(rest.priority4)
  
  #saving output
  writeRaster(rest.priority4,output.name,overwrite=TRUE)
  
  #removing temporary folder
  temp_dir<-paste(getwd(),gmeta()$LOCATION_NAME[1],sep="/")
  unlink(temp_dir,recursive=T,force=T)
  
  return(rest.priority4)
}
