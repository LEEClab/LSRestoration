#' @title Finds the priority areas for restoration of any ecosystem services in BUNDLE 5.
#' @name bundle5
#'
#' @description  The aim of this function is to give restoration priority to regions that can connect the already established SPUs. For this function, we recommend that the user first uses the recent released LSCorridors software (Ribeiro et al. 2017).The output raster map of this sofware will serve as input for this function. 
#'
#' @param output.name the name of the output raster map.
#' @param rest.map a restoration map, as raster file, which should contain the delimitation (or boundaries) of the area available for restoration in the study landscape and, if possible, a surface of restoration feasibility/suitability.
#' @param corridors.map a raster map which corresponds to the output map from LSCorridors software. It shows how many of the corridor simulations passed through each pixel of the map.
#'
#' @details This function takes the RSFI map resultant from a simulation in the LSCorridors software, multiplies it with the restoration map and rescales the product from zero to 1.
#'
#' @return A map with restoration priorities for the mantainance of the ecosystem service.
#'
#' @author Gabriela Teixeira Duarte, Felipe Martello, Milton Cezar Ribeiro
#'
#' @seealso \url{link github}, \url{link artigo}
#'
#' @examples
#' bundle5(rest.map= "pastures.tif",corridors.map = "lscorridors_output.tif",ouput.name="restbundle5.tif")
#'
#'
#' output.name<-"restbundle5.tif"
#' rest.map<-raster("restoration_areas.tif")
#' corridors.map<-raster("rsfi_lscorridors.tif")
#' bundle5.results<- bundle5(rest.map, corridors.map, output.name)
#'
#' @import raster
#' @import rgdal
#' 
#' @export

bundle5<-function(rest.map,corridors.map,output.name){
          
  #reformulating the input raster maps  
  rest.map.na<-rest.map
  rest.map.na[rest.map.na==0]<-NA

  #clipping by potential restoration areas
  foo<-data.frame(cbind(corridors.map[],rest.map.na[]))
  colnames(foo)<-c("corr","rest")
  foo$estimate<-foo$corr*foo$rest
  foo.benf<-rest.map
  foo.benf[]<-foo$estimate
  rest.benf<-foo.benf
  
  #forcing range from 0 to 1 
  rest.priority5<-rest.benf/max(na.omit(rest.benf[]))
  crs(rest.priority5)<-crs(rest.map)
  plot(rest.priority5)
  
  #saving output
  writeRaster(rest.priority5,output.name,overwrite=TRUE)
  
  return(rest.priority5)
}
    
  