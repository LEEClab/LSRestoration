#' @title Finds the priority areas for restoration of any ecosystem services in BUNDLE 9.
#' @name bundle9
#'
#' @description The aim of this function is to give restoration priority to areas with steeper and longer slopes. We assume that the benefit from restoration will increase with the increase of erosion potential, which is related to the slope length-gradient factor in the Universal Soil Loss Equation (Wischmeier and Smith 1978).
#'
#' @param dir.grass the absolute filepath representing the folder where Grass GIS is installed.
#' @param output.name the name of the output raster map.
#' @param rest.map a restoration map, as raster file, which should contain the delimitation (or boundaries) of the area available for restoration in the study landscape and, if possible, a surface of restoration feasibility/suitability.
#' @param dem.map a raster file with the digital elevation model for the landscape of interest. 
#' @param threshold a threshold value, which specifies the minimum size of an exterior watershed basin in cells number. As defined in the GRASS GIS manual, "the minimum size of drainage basins, defined by the threshold parameter, is only relevant for those watersheds with a single stream having at least the threshold of cells flowing into it. These watersheds are called exterior basins".
#' 
#' @details The function will first calculate the slope length gradient factor and, then, multiply the resultant map with the restoration map ("rest.map").
#'
#' @return A map with restoration priorities for the mantainance of the ecosystem service.
#'
#' @author Gabriela Teixeira Duarte, Felipe Martello, Milton Cezar Ribeiro
#'
#' @seealso \url{link github}, \url{link artigo}
#'
#' @examples
#' bundle9(rest.map = "pasture.tif",dem.map = "dem.tif",threshold=1000,ouput.name="restbundle9.tif", dir.grass="C:\\Program Files\\GRASS GIS 7.4.0")
#'
#' dir.grass<-"C:\\Program Files\\GRASS GIS 7.4.0"
#' output.name<-"restbundle9.tif"
#' rest.map<-raster("restoration_areas.tif")
#' dem.map<-raster("dem.tif")
#' threshold<- 100
#' bundle9.results<- bundle9(dir.grass, rest.map, dem.map, threshold, output.name)
#'@import rgrass7
#'@import rgdal
#'@import raster
#'
#' @export

bundle9<-function(dir.grass,rest.map,dem.map,threshold,output.name){ 
  
  #adress of grass directory
  initGRASS(gisBase = dir.grass, home = getwd(), gisDbase=getwd(),override=TRUE)
  
  #reformulating the input raster maps  
  rest.map.na<-rest.map
  rest.map.na[rest.map.na==0]<-NA
  
  #finding the LS-factor
  writeRAST(as(dem.map, "SpatialGridDataFrame"), "mapDEM", flags = c("overwrite"))
  execGRASS("g.region",raster = "mapDEM")
  execGRASS("r.watershed", flags="overwrite", parameters=list(threshold= threshold,elevation="mapDEM", length_slope="lsfact"))
  lsfactor<-raster(readRAST("lsfact"))
  
  #clipping by potential restoration areas
  foo<-data.frame(cbind(lsfactor[],rest.map.na[]))
  colnames(foo)<-c("ls","rest")
  foo$estimate<-foo$ls*foo$rest
  foo.benf<-rest.map
  foo.benf[]<-foo$estimate
  rest.benf<-foo.benf

#forcing range of 0 to 1 
  rest.priority9<-rest.benf/max(na.omit(rest.benf[]))
  crs(rest.priority9)<-crs(rest.map)
  plot(rest.priority9)
  
  #saving output
  writeRaster(rest.priority9,output.name,overwrite=TRUE)
  
  #removing temporary folder
  temp_dir<-paste(getwd(),gmeta()$LOCATION_NAME[1],sep="/")
  unlink(temp_dir,recursive=T,force=T)
  
  return(rest.priority9)
}

